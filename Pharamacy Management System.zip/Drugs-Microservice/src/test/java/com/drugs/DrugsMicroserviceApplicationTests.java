package com.drugs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugsMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
